/*
 * Created on Mar 17, 2004
 * Version $Id$
 */
package com.pnehrer.rss.internal.ui.editor;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CLabel;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.part.EditorPart;

import com.pnehrer.rss.core.IChannel;
import com.pnehrer.rss.core.IItem;
import com.pnehrer.rss.core.RSSCore;
import com.pnehrer.rss.ui.RSSUI;

/**
 * @author <a href="mailto:pnehrer@freeshell.org">Peter Nehrer</a>
 * @see EditorPart
 */
public class ChannelEditor extends EditorPart {

    private Font titleFont;
    private Image image;
    private CLabel title;
    private Text description;
    private IChannel channel;
    private boolean dirty;

	/**
	 * @see EditorPart#createPartControl
	 */
	public void createPartControl(Composite parent) {
        titleFont = parent.getFont();
        FontData[] fd = titleFont.getFontData();
        titleFont = 
            new Font(
                parent.getDisplay(), 
                fd[0].getName(), 
                fd[0].getHeight(), 
                fd[0].getStyle() | SWT.BOLD);

        ScrolledComposite scrollable = new ScrolledComposite(parent, SWT.V_SCROLL);
        scrollable.setExpandVertical(true);
        
        Composite composite = new Composite(scrollable, SWT.NONE);
        composite.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
        composite.setLayout(new GridLayout());
        scrollable.setContent(composite);

        ImageDescriptor descriptor = RSSUI.getDefault().getImageDescriptor(channel);
        if(descriptor != null)
            image = descriptor.createImage();

        title = new CLabel(composite, SWT.SHADOW_NONE);
        title.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
        title.setImage(image);
        title.setFont(JFaceResources.getBannerFont());
        title.setText(channel.getTitle());
        
        description = new Text(composite, SWT.MULTI | SWT.WRAP | SWT.READ_ONLY);
        description.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
        if(channel.getDescription() != null)
            description.setText(channel.getDescription());        
        
        IItem[] items = channel.getItems();
        for(int i = 0; i < items.length; ++i)
            createItemGroup(composite, items[i]);
            
        scrollable.setMinSize(composite.computeSize(SWT.DEFAULT, SWT.DEFAULT));
	}
    
    private void createItemGroup(Composite composite, IItem item) {
        Text title = new Text(composite, SWT.MULTI | SWT.WRAP | SWT.READ_ONLY);
        title.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
        title.setFont(titleFont);
        title.setText(item.getTitle());
        
        StyledText description = new StyledText(composite, SWT.MULTI | SWT.WRAP | SWT.READ_ONLY);
        GridData gd = new GridData(GridData.FILL_HORIZONTAL);
        gd.horizontalIndent = 20;
        description.setLayoutData(gd);
        description.setFont(composite.getFont());
        if(item.getDescription() != null)
            description.setText(item.getDescription());
        
//        Point size = description.getSize();
//        size.y = description.getLineHeight() * description.getLineCount(); 
//        description.setSize(size);
//        description.addControlListener(new ControlListener() {
//            public void controlMoved(ControlEvent e) {
//            }
//
//            public void controlResized(ControlEvent e) {
//                Point size = description.getSize();
//                size.y = description.getLineHeight() * description.getLineCount(); 
//                description.setSize(size);
//            }
//        });
    }

	/**
	 * @see EditorPart#setFocus
	 */
	public void setFocus() {
        title.setFocus();
	}

	/**
	 * @see EditorPart#doSave
	 */
	public void doSave(IProgressMonitor monitor) {
        if(monitor != null)
            monitor.beginTask("", 1);
            
        try {
            // TODO Implement me!
            // ...
            setDirty(false);
        }
        finally {
            if(monitor != null)
                monitor.done();
        }
	}

	/**
	 * @see EditorPart#doSaveAs
	 */
	public void doSaveAs() {
	}

	/**
	 * @see EditorPart#isDirty
	 */
	public boolean isDirty() {
		return dirty;
	}

	/**
	 * @see EditorPart#isSaveAsAllowed
	 */
	public boolean isSaveAsAllowed() {
		return false;
	}

	/**
	 * @see EditorPart#gotoMarker
	 */
	public void gotoMarker(IMarker marker) {
	}

	/**
	 * @see EditorPart#init
	 */
	public void init(IEditorSite site, IEditorInput input) throws PartInitException {
        if(input instanceof IFileEditorInput) {
            setSite(site);
            setInput(input);
            try {
                channel = RSSCore.getPlugin().getChannel(((IFileEditorInput)input).getFile());
            }
            catch(CoreException e) {
                throw new PartInitException(e.getStatus());
            }
        }
        else
            throw new PartInitException("Input must be a channel file.");
	}
    
    /* (non-Javadoc)
     * @see org.eclipse.ui.IWorkbenchPart#dispose()
     */
    public void dispose() {
        if(image != null)
            image.dispose();
            
        if(titleFont != null)
            titleFont.dispose();
            
        super.dispose();
    }
    
    private void setDirty(boolean dirty) {
        boolean changed = this.dirty != dirty;
        this.dirty = dirty;
        if(changed)
            firePropertyChange(PROP_DIRTY);
    }
}
