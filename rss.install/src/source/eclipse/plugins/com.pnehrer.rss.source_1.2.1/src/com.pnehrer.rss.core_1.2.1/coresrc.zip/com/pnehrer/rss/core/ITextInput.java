/*
 * Created on Nov 5, 2003
 * Version $Id: ITextInput.java,v 1.4 2004/03/16 13:58:44 pnehrer Exp $
 */
package com.pnehrer.rss.core;

/**
 * @author <a href="mailto:pnehrer@freeshell.org">Peter Nehrer</a>
 */
public interface ITextInput extends IRSSElement {

    public String getDescription();
    
    public String getName();
}
