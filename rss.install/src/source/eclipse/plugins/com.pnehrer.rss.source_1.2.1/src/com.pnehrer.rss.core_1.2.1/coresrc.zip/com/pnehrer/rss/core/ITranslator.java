/*
 * Created on Nov 18, 2003
 * Version $Id: ITranslator.java,v 1.3 2004/03/16 13:58:44 pnehrer Exp $
 */
package com.pnehrer.rss.core;

import org.eclipse.core.runtime.CoreException;
import org.w3c.dom.Document;

/**
 * @author <a href="mailto:pnehrer@freeshell.org">Peter Nehrer</a>
 */
public interface ITranslator {

    public boolean canTranslate(Document document);
    
    public Document translate(Document document) throws CoreException;
}
