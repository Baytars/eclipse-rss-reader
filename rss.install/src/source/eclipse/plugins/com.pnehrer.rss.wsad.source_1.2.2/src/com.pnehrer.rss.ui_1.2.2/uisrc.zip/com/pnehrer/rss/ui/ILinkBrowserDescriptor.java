/*
 * Created on Dec 17, 2003
 * Version $Id: ILinkBrowserDescriptor.java,v 1.1 2003/12/18 07:19:15 pnehrer Exp $
 */
package com.pnehrer.rss.ui;

/**
 * @author <a href="mailto:pnehrer@freeshell.org">Peter Nehrer</a>
 */
public interface ILinkBrowserDescriptor {

    public String getId();

    public String getLabel();
}
