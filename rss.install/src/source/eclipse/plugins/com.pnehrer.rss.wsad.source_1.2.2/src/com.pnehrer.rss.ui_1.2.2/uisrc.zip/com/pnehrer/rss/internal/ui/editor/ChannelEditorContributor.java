/*
 * Created on Mar 17, 2004
 * Version $Id: ChannelEditorContributor.java,v 1.1 2004/07/06 04:54:50 pnehrer Exp $
 */
package com.pnehrer.rss.internal.ui.editor;

import org.eclipse.ui.part.EditorActionBarContributor;

/**
 * @author <a href="mailto:pnehrer@freeshell.org">Peter Nehrer</a>
 * @see EditorActionBarContributor
 */
public class ChannelEditorContributor extends EditorActionBarContributor {

}
