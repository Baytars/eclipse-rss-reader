/*
 * Created on Nov 5, 2003
 * Version $Id: IImage.java,v 1.5 2004/03/16 13:58:44 pnehrer Exp $
 */
package com.pnehrer.rss.core;

import java.net.URL;

/**
 * @author <a href="mailto:pnehrer@freeshell.org">Peter Nehrer</a>
 */
public interface IImage extends IRSSElement {
    
    public URL getURL();
}
