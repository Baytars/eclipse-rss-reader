/*
 * Created on Dec 4, 2003
 * Version $Id: IRSSElement.java,v 1.4 2004/07/06 04:34:58 pnehrer Exp $
 */
package com.pnehrer.rss.core;

import org.eclipse.core.runtime.IAdaptable;

/**
 * @author <a href="mailto:pnehrer@freeshell.org">Peter Nehrer</a>
 */
public interface IRSSElement extends IAdaptable {

    public IChannel getChannel();

    public String getTitle();
    
    public String getLink();
}
